-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 30, 2021 at 06:58 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `adminId` int(11) NOT NULL,
  `adminName` varchar(255) NOT NULL,
  `adminUser` varchar(255) NOT NULL,
  `adminEmail` varchar(255) NOT NULL,
  `adminPass` varchar(30) NOT NULL,
  `level` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`adminId`, `adminName`, `adminUser`, `adminEmail`, `adminPass`, `level`) VALUES
(1, 'Md Muzibur Rahman Rukon', 'Rukon', 'muziburrahmanrukon@gmail.com', '123', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_brand`
--

CREATE TABLE `tbl_brand` (
  `brandId` int(11) NOT NULL,
  `brandName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_brand`
--

INSERT INTO `tbl_brand` (`brandId`, `brandName`) VALUES
(2, 'Samsung'),
(3, 'Canon'),
(4, 'IPhone'),
(5, 'Acer');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cart`
--

CREATE TABLE `tbl_cart` (
  `cartId` int(11) NOT NULL,
  `sId` varchar(255) NOT NULL,
  `productId` int(11) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `price` float(10,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_cart`
--

INSERT INTO `tbl_cart` (`cartId`, `sId`, `productId`, `productName`, `price`, `quantity`, `image`) VALUES
(12, '3vnd6dpf4qaotu5472d64rtrui', 14, 'Iphone8', 700.00, 1, 'uploads/677db3dd3d.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_catagory`
--

CREATE TABLE `tbl_catagory` (
  `catId` int(11) NOT NULL,
  `catName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_catagory`
--

INSERT INTO `tbl_catagory` (`catId`, `catName`) VALUES
(2, 'Desktop'),
(3, 'Laptop'),
(4, 'Mobaile Phone'),
(5, 'Accessories'),
(6, 'Software'),
(7, 'Sports &amp; amp Fitness'),
(8, 'Footwear'),
(9, 'Jowollary');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_compare`
--

CREATE TABLE `tbl_compare` (
  `id` int(11) NOT NULL,
  `cmrId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `price` float(10,2) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE `tbl_customer` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`id`, `name`, `address`, `city`, `country`, `zip`, `phone`, `email`, `pass`) VALUES
(1, 'Muzibur', '168/6,Surma,Sulogor', 'Sunamgonj', 'Bangladesh', '3000', '01748613498', 'admin@gmail.com', 'pass'),
(2, 'Afrin', '168/7,Surma,Sulogor', 'Sunamgonj', 'Bangladesh', '3000', '01748613498', 'ajijul@gmail.com', 'pass'),
(3, 'Rahi', 'Sylhet', 'Sylhet', 'Bangladesh', '3100', '01748613498', 'marjanahmed49002@gmail.com', 'pass'),
(4, 'Afra', 'Sylhet', 'Su', 'Bangladesh', '3100', '01748613498', 'afra@gmail.com', '123');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `id` int(11) NOT NULL,
  `cmrId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` float(10,2) NOT NULL,
  `image` varchar(255) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`id`, `cmrId`, `productId`, `productName`, `quantity`, `price`, `image`, `date`, `status`) VALUES
(10, 4, 11, 'Apache 10', 1, 270.00, 'uploads/342350edbc.png', '2019-08-17 18:02:12', 2),
(12, 4, 9, 'Laptop', 2, 20000000.00, 'uploads/1433ec042a.jpg', '2019-08-19 06:15:21', 0),
(13, 4, 11, 'Apache 10', 1, 270.00, 'uploads/342350edbc.png', '2019-08-19 07:27:21', 0),
(14, 4, 15, 'Iphone7', 1, 600.00, 'uploads/33307439b2.jpg', '2019-08-19 07:39:38', 0),
(15, 4, 11, 'Apache 10', 1, 270.00, 'uploads/342350edbc.png', '2019-08-19 07:39:57', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `productId` int(11) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `catId` int(11) NOT NULL,
  `brandId` int(11) NOT NULL,
  `body` text NOT NULL,
  `price` float(10,3) NOT NULL,
  `image` varchar(255) NOT NULL,
  `type` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`productId`, `productName`, `catId`, `brandId`, `body`, `price`, `image`, `type`) VALUES
(2, 'Iron', 5, 2, '<p>h j r m t o c&nbsp;h j r m t o c&nbsp;h j r m t o c&nbsp;h j r m t o c&nbsp;h j r m t o c&nbsp;h j r m t o c&nbsp;h j r m t o c&nbsp;h j r m t o c&nbsp;h j r m t o c&nbsp;h j r m t o c&nbsp;h j r m t o c&nbsp;h j r m t o c&nbsp;h j r m t o c&nbsp;h j r m t o c&nbsp;h j r m t o c&nbsp;h j r m t o c&nbsp;h j r m t o c&nbsp;h j r m t o c&nbsp;h j r m t o c&nbsp;h j r m t o c&nbsp;h j r m t o c&nbsp;h j r m t o c&nbsp;h j r m t o c&nbsp;</p>', 270.000, 'uploads/fb66af4a72.png', 0),
(3, 'Fan', 5, 2, '<p>sale t c&nbsp;sale t c&nbsp;sale t c&nbsp;sale t c&nbsp;sale t c&nbsp;sale t c&nbsp;sale t c&nbsp;sale t c&nbsp;sale t c&nbsp;sale t c&nbsp;sale t c</p>\r\n<p>&nbsp;</p>\r\n<p>sale t c&nbsp;sale t c&nbsp;sale t c&nbsp;sale t c&nbsp;sale t c&nbsp;sale t c&nbsp;sale t c&nbsp;sale t c&nbsp;sale t c&nbsp;sale t c&nbsp;sale t c&nbsp;sale t c&nbsp;sale t c</p>', 490.000, 'uploads/0f37711f7d.jpg', 1),
(5, 'Blandery', 9, 4, '<p>sale t c&nbsp;sale t c&nbsp;sale t c&nbsp;sale t c&nbsp;sale t c&nbsp;sale t c&nbsp;sale t c&nbsp;sale t c&nbsp;sale t c&nbsp;sale t c&nbsp;sale t c&nbsp;sale t c&nbsp;sale t c&nbsp;sale t c h m t c</p>', 5000.000, 'uploads/c3d61fd242.png', 0),
(6, 'Blander', 3, 4, '<p>sale t c&nbsp;sale t c&nbsp;sale t c&nbsp;sale t c</p>', 600.000, 'uploads/121e163c48.png', 1),
(7, 'Mobaile Phone', 4, 4, '<p>iphokne fjdifjdvn djfoeppoj;sMC,X FJD VDKFJDFH DFHIEOPW&nbsp; NKDFJO DKFJO DKJOEWE DKJFPOAFJDFJ<img title=\"Cool\" src=\"js/tiny-mce/plugins/emotions/img/smiley-cool.gif\" alt=\"Cool\" border=\"0\" /></p>', 300000.000, 'uploads/c8b0914843.png', 1),
(8, 'Laptop', 3, 3, '<p>iphokne fjdifjdvn djfoeppoj;sMC,X FJD VDKFJDFH DFHIEOPW&nbsp; NKDFJO DKFJO DKJOEWE DKJFPOAFJDFJ<img title=\"Cool\" src=\"js/tiny-mce/plugins/emotions/img/smiley-cool.gif\" alt=\"Cool\" border=\"0\" /></p>\r\n<p>iphokne fjdifjdvn djfoeppoj;sMC,X FJD VDKFJDFH DFHIEOPW&nbsp; NKDFJO DKFJO DKJOEWE DKJFPOAFJDFJ<img title=\"Cool\" src=\"js/tiny-mce/plugins/emotions/img/smiley-cool.gif\" alt=\"Cool\" border=\"0\" /></p>\r\n<p>iphokne fjdifjdvn djfoeppoj;sMC,X FJD VDKFJDFH DFHIEOPW&nbsp; NKDFJO DKFJO DKJOEWE DKJFPOAFJDFJ<img title=\"Cool\" src=\"js/tiny-mce/plugins/emotions/img/smiley-cool.gif\" alt=\"Cool\" border=\"0\" /></p>\r\n<p>iphokne fjdifjdvn djfoeppoj;sMC,X FJD VDKFJDFH DFHIEOPW&nbsp; NKDFJO DKFJO DKJOEWE DKJFPOAFJDFJ<img title=\"Cool\" src=\"js/tiny-mce/plugins/emotions/img/smiley-cool.gif\" alt=\"Cool\" border=\"0\" /></p>\r\n<p>iphokne fjdifjdvn djfoeppoj;sMC,X FJD VDKFJDFH DFHIEOPW&nbsp; NKDFJO DKFJO DKJOEWE DKJFPOAFJDFJ<img title=\"Cool\" src=\"js/tiny-mce/plugins/emotions/img/smiley-cool.gif\" alt=\"Cool\" border=\"0\" /></p>\r\n<p>iphokne fjdifjdvn djfoeppoj;sMC,X FJD VDKFJDFH DFHIEOPW&nbsp; NKDFJO DKFJO DKJOEWE DKJFPOAFJDFJ<img title=\"Cool\" src=\"js/tiny-mce/plugins/emotions/img/smiley-cool.gif\" alt=\"Cool\" border=\"0\" /></p>\r\n<p>iphokne fjdifjdvn djfoeppoj;sMC,X FJD VDKFJDFH DFHIEOPW&nbsp; NKDFJO DKFJO DKJOEWE DKJFPOAFJDFJ<img title=\"Cool\" src=\"js/tiny-mce/plugins/emotions/img/smiley-cool.gif\" alt=\"Cool\" border=\"0\" /></p>', 10000000.000, 'uploads/50df385418.jpg', 0),
(9, 'Laptop', 2, 2, '<p>iphokne fjdifjdvn djfoeppoj;sMC,X FJD VDKFJDFH DFHIEOPW&nbsp; NKDFJO DKFJO DKJOEWE DKJFPOAFJDFJ<img title=\"Cool\" src=\"js/tiny-mce/plugins/emotions/img/smiley-cool.gif\" alt=\"Cool\" border=\"0\" /></p>\r\n<p>iphokne fjdifjdvn djfoeppoj;sMC,X FJD VDKFJDFH DFHIEOPW&nbsp; NKDFJO DKFJO DKJOEWE DKJFPOAFJDFJ<img title=\"Cool\" src=\"js/tiny-mce/plugins/emotions/img/smiley-cool.gif\" alt=\"Cool\" border=\"0\" /></p>', 10000000.000, 'uploads/1433ec042a.jpg', 0),
(10, 'Desktop', 6, 0, '<p>iphokne fjdifjdvn djfoeppoj;sMC,X FJD VDKFJDFH DFHIEOPW&nbsp; NKDFJO DKFJO DKJOEWE DKJFPOAFJDFJ<img title=\"Cool\" src=\"js/tiny-mce/plugins/emotions/img/smiley-cool.gif\" alt=\"Cool\" border=\"0\" /></p>\r\n<p>iphokne fjdifjdvn djfoeppoj;sMC,X FJD VDKFJDFH DFHIEOPW&nbsp; NKDFJO DKFJO DKJOEWE DKJFPOAFJDFJ<img title=\"Cool\" src=\"js/tiny-mce/plugins/emotions/img/smiley-cool.gif\" alt=\"Cool\" border=\"0\" /></p>\r\n<p>iphokne fjdifjdvn djfoeppoj;sMC,X FJD VDKFJDFH DFHIEOPW&nbsp; NKDFJO DKFJO DKJOEWE DKJFPOAFJDFJ<img title=\"Cool\" src=\"js/tiny-mce/plugins/emotions/img/smiley-cool.gif\" alt=\"Cool\" border=\"0\" /></p>', 10000000.000, 'uploads/1ea86315b7.jpg', 1),
(11, 'Apache 10', 6, 4, '<p>iphokne fjdifjdvn djfoeppoj;sMC,X FJD VDKFJDFH DFHIEOPW&nbsp; NKDFJO DKFJO DKJOEWE DKJFPOAFJDFJ<img title=\"Cool\" src=\"js/tiny-mce/plugins/emotions/img/smiley-cool.gif\" alt=\"Cool\" border=\"0\" /></p>\r\n<p>iphokne fjdifjdvn djfoeppoj;sMC,X FJD VDKFJDFH DFHIEOPW&nbsp; NKDFJO DKFJO DKJOEWE DKJFPOAFJDFJ<img title=\"Cool\" src=\"js/tiny-mce/plugins/emotions/img/smiley-cool.gif\" alt=\"Cool\" border=\"0\" /></p>\r\n<p>iphokne fjdifjdvn djfoeppoj;sMC,X FJD VDKFJDFH DFHIEOPW&nbsp; NKDFJO DKFJO DKJOEWE DKJFPOAFJDFJ<img title=\"Cool\" src=\"js/tiny-mce/plugins/emotions/img/smiley-cool.gif\" alt=\"Cool\" border=\"0\" /></p>\r\n<p>iphokne fjdifjdvn djfoeppoj;sMC,X FJD VDKFJDFH DFHIEOPW&nbsp; NKDFJO DKFJO DKJOEWE DKJFPOAFJDFJ<img title=\"Cool\" src=\"js/tiny-mce/plugins/emotions/img/smiley-cool.gif\" alt=\"Cool\" border=\"0\" /></p>', 270.000, 'uploads/342350edbc.png', 0),
(12, 'IPhone10', 7, 4, '<p>iphokne fjdifjdvn djfoeppoj;sMC,X FJD VDKFJDFH DFHIEOPW&nbsp; NKDFJO DKFJO DKJOEWE DKJFPOAFJDFJ<img title=\"Cool\" src=\"js/tiny-mce/plugins/emotions/img/smiley-cool.gif\" alt=\"Cool\" border=\"0\" /><img title=\"Tongue Out\" src=\"js/tiny-mce/plugins/emotions/img/smiley-tongue-out.gif\" alt=\"Tongue Out\" border=\"0\" /><img title=\"Undecided\" src=\"js/tiny-mce/plugins/emotions/img/smiley-undecided.gif\" alt=\"Undecided\" border=\"0\" /></p>\r\n<p>iphokne fjdifjdvn djfoeppoj;sMC,X FJD VDKFJDFH DFHIEOPW&nbsp; NKDFJO DKFJO DKJOEWE DKJFPOAFJDFJ<img title=\"Cool\" src=\"js/tiny-mce/plugins/emotions/img/smiley-cool.gif\" alt=\"Cool\" border=\"0\" /><img title=\"Tongue Out\" src=\"js/tiny-mce/plugins/emotions/img/smiley-tongue-out.gif\" alt=\"Tongue Out\" border=\"0\" /><img title=\"Undecided\" src=\"js/tiny-mce/plugins/emotions/img/smiley-undecided.gif\" alt=\"Undecided\" border=\"0\" /></p>\r\n<p>iphokne fjdifjdvn djfoeppoj;sMC,X FJD VDKFJDFH DFHIEOPW&nbsp; NKDFJO DKFJO DKJOEWE DKJFPOAFJDFJ<img title=\"Cool\" src=\"js/tiny-mce/plugins/emotions/img/smiley-cool.gif\" alt=\"Cool\" border=\"0\" /><img title=\"Tongue Out\" src=\"js/tiny-mce/plugins/emotions/img/smiley-tongue-out.gif\" alt=\"Tongue Out\" border=\"0\" /><img title=\"Undecided\" src=\"js/tiny-mce/plugins/emotions/img/smiley-undecided.gif\" alt=\"Undecided\" border=\"0\" /></p>\r\n<p>iphokne fjdifjdvn djfoeppoj;sMC,X FJD VDKFJDFH DFHIEOPW&nbsp; NKDFJO DKFJO DKJOEWE DKJFPOAFJDFJ<img title=\"Cool\" src=\"js/tiny-mce/plugins/emotions/img/smiley-cool.gif\" alt=\"Cool\" border=\"0\" /><img title=\"Tongue Out\" src=\"js/tiny-mce/plugins/emotions/img/smiley-tongue-out.gif\" alt=\"Tongue Out\" border=\"0\" /><img title=\"Undecided\" src=\"js/tiny-mce/plugins/emotions/img/smiley-undecided.gif\" alt=\"Undecided\" border=\"0\" /></p>', 10000000.000, 'uploads/1e15bdfd1f.png', 1),
(13, 'Iphone9', 4, 4, '<p>iphokne fjdifjdvn djfoeppoj;sMC,X FJD VDKFJDFH DFHIEOPW&nbsp; NKDFJO DKFJO DKJOEWE DKJFPOAFJDFJ<img title=\"Cool\" src=\"js/tiny-mce/plugins/emotions/img/smiley-cool.gif\" alt=\"Cool\" border=\"0\" /><img title=\"Tongue Out\" src=\"js/tiny-mce/plugins/emotions/img/smiley-tongue-out.gif\" alt=\"Tongue Out\" border=\"0\" /><img title=\"Undecided\" src=\"js/tiny-mce/plugins/emotions/img/smiley-undecided.gif\" alt=\"Undecided\" border=\"0\" /></p>', 200.000, 'uploads/baf635e7f5.jpg', 1),
(14, 'Iphone8', 4, 4, '<p>iphokne fjdifjdvn djfoeppoj;sMC,X FJD VDKFJDFH DFHIEOPW&nbsp; NKDFJO DKFJO DKJOEWE DKJFPOAFJDFJ<img title=\"Cool\" src=\"js/tiny-mce/plugins/emotions/img/smiley-cool.gif\" alt=\"Cool\" border=\"0\" /><img title=\"Tongue Out\" src=\"js/tiny-mce/plugins/emotions/img/smiley-tongue-out.gif\" alt=\"Tongue Out\" border=\"0\" /><img title=\"Undecided\" src=\"js/tiny-mce/plugins/emotions/img/smiley-undecided.gif\" alt=\"Undecided\" border=\"0\" /></p>\r\n<p>iphokne fjdifjdvn djfoeppoj;sMC,X FJD VDKFJDFH DFHIEOPW&nbsp; NKDFJO DKFJO DKJOEWE DKJFPOAFJDFJ<img title=\"Cool\" src=\"js/tiny-mce/plugins/emotions/img/smiley-cool.gif\" alt=\"Cool\" border=\"0\" /><img title=\"Tongue Out\" src=\"js/tiny-mce/plugins/emotions/img/smiley-tongue-out.gif\" alt=\"Tongue Out\" border=\"0\" /><img title=\"Undecided\" src=\"js/tiny-mce/plugins/emotions/img/smiley-undecided.gif\" alt=\"Undecided\" border=\"0\" /></p>', 700.000, 'uploads/677db3dd3d.jpg', 0),
(15, 'Iphone7', 9, 3, '<p>iphokne fjdifjdvn djfoeppoj;sMC,X FJD VDKFJDFH DFHIEOPW&nbsp; NKDFJO DKFJO DKJOEWE DKJFPOAFJDFJ<img title=\"Cool\" src=\"js/tiny-mce/plugins/emotions/img/smiley-cool.gif\" alt=\"Cool\" border=\"0\" /><img title=\"Tongue Out\" src=\"js/tiny-mce/plugins/emotions/img/smiley-tongue-out.gif\" alt=\"Tongue Out\" border=\"0\" /><img title=\"Undecided\" src=\"js/tiny-mce/plugins/emotions/img/smiley-undecided.gif\" alt=\"Undecided\" border=\"0\" /></p>\r\n<p>iphokne fjdifjdvn djfoeppoj;sMC,X FJD VDKFJDFH DFHIEOPW&nbsp; NKDFJO DKFJO DKJOEWE DKJFPOAFJDFJ<img title=\"Cool\" src=\"js/tiny-mce/plugins/emotions/img/smiley-cool.gif\" alt=\"Cool\" border=\"0\" /><img title=\"Tongue Out\" src=\"js/tiny-mce/plugins/emotions/img/smiley-tongue-out.gif\" alt=\"Tongue Out\" border=\"0\" /><img title=\"Undecided\" src=\"js/tiny-mce/plugins/emotions/img/smiley-undecided.gif\" alt=\"Undecided\" border=\"0\" /></p>\r\n<p>iphokne fjdifjdvn djfoeppoj;sMC,X FJD VDKFJDFH DFHIEOPW&nbsp; NKDFJO DKFJO DKJOEWE DKJFPOAFJDFJ<img title=\"Cool\" src=\"js/tiny-mce/plugins/emotions/img/smiley-cool.gif\" alt=\"Cool\" border=\"0\" /><img title=\"Tongue Out\" src=\"js/tiny-mce/plugins/emotions/img/smiley-tongue-out.gif\" alt=\"Tongue Out\" border=\"0\" /><img title=\"Undecided\" src=\"js/tiny-mce/plugins/emotions/img/smiley-undecided.gif\" alt=\"Undecided\" border=\"0\" /></p>\r\n<p>iphokne fjdifjdvn djfoeppoj;sMC,X FJD VDKFJDFH DFHIEOPW&nbsp; NKDFJO DKFJO DKJOEWE DKJFPOAFJDFJ<img title=\"Cool\" src=\"js/tiny-mce/plugins/emotions/img/smiley-cool.gif\" alt=\"Cool\" border=\"0\" /><img title=\"Tongue Out\" src=\"js/tiny-mce/plugins/emotions/img/smiley-tongue-out.gif\" alt=\"Tongue Out\" border=\"0\" /><img title=\"Undecided\" src=\"js/tiny-mce/plugins/emotions/img/smiley-undecided.gif\" alt=\"Undecided\" border=\"0\" /></p>\r\n<p>iphokne fjdifjdvn djfoeppoj;sMC,X FJD VDKFJDFH DFHIEOPW&nbsp; NKDFJO DKFJO DKJOEWE DKJFPOAFJDFJ<img title=\"Cool\" src=\"js/tiny-mce/plugins/emotions/img/smiley-cool.gif\" alt=\"Cool\" border=\"0\" /><img title=\"Tongue Out\" src=\"js/tiny-mce/plugins/emotions/img/smiley-tongue-out.gif\" alt=\"Tongue Out\" border=\"0\" /><img title=\"Undecided\" src=\"js/tiny-mce/plugins/emotions/img/smiley-undecided.gif\" alt=\"Undecided\" border=\"0\" /></p>', 600.000, 'uploads/33307439b2.jpg', 0),
(16, 'Iron', 9, 5, '<p>ita ekta test so jowollary banan o joidi vul oy maniya low hy adom sonthan</p>', 490.000, 'uploads/fb471d46be.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_wlist`
--

CREATE TABLE `tbl_wlist` (
  `id` int(11) NOT NULL,
  `cmrId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `price` float(10,2) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`adminId`);

--
-- Indexes for table `tbl_brand`
--
ALTER TABLE `tbl_brand`
  ADD PRIMARY KEY (`brandId`);

--
-- Indexes for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  ADD PRIMARY KEY (`cartId`);

--
-- Indexes for table `tbl_catagory`
--
ALTER TABLE `tbl_catagory`
  ADD PRIMARY KEY (`catId`);

--
-- Indexes for table `tbl_compare`
--
ALTER TABLE `tbl_compare`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`productId`);

--
-- Indexes for table `tbl_wlist`
--
ALTER TABLE `tbl_wlist`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `adminId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_brand`
--
ALTER TABLE `tbl_brand`
  MODIFY `brandId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  MODIFY `cartId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tbl_catagory`
--
ALTER TABLE `tbl_catagory`
  MODIFY `catId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_compare`
--
ALTER TABLE `tbl_compare`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `productId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tbl_wlist`
--
ALTER TABLE `tbl_wlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
